alter table ESHOP_LINE_ITEM add column SUM_ decimal(19, 2) ;
